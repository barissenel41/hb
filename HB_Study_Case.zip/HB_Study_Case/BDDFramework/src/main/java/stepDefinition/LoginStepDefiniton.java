package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.functions.ExpectedCondition;
import io.cucumber.messages.internal.com.google.protobuf.Duration;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

public class LoginStepDefiniton {
	
	public static WebDriver driver;
    
	 String baseURL = "https://www.hepsiburada.com";

	@Given("^Login olmak icin kullanıcı siteye girer$")
	
	public void siteye_girme() {
		
		System.out.println(System.getProperty("user.dir"));
        System.setProperty("webdriver.chrome.driver",
              System.getProperty("user.dir")+"//resources//drivers//chromedriver");
     // System.getProperty("user.dir") + "/Users/cengiz.senel/git/BDDFramework/resources/drivers/chromedriver");
		
	
		 driver = new ChromeDriver(chromeOptions());
		 
         driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
         driver.manage().window().maximize();
         driver.get(baseURL);  
        
	}
	

		protected ChromeOptions chromeOptions() {
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("--test-type");
			chromeOptions.addArguments("--disable-popup-blocking");
			chromeOptions.addArguments("--ignore-certificate-errors");
			chromeOptions.addArguments("--disable-translate");
			chromeOptions.addArguments("--start-maximized");
			chromeOptions.addArguments("--disable-notifications");
			chromeOptions.addArguments("disable-automatic-password-saving");
			chromeOptions.addArguments("allow-silent-push");
			chromeOptions.addArguments("disable-infobars");
		//	(CapabilityType.ACCEPT_SSL_CERTS, true)
		//	https://www.guru99.com/ssl-certificate-error-handling-selenium.html
			//https://stackoverflow.com/questions/2405714/selenium-and-https-ssl/3673404
			return chromeOptions;
		}
		
	


	@When("^Giriş butonuna tıklar$")
	public void giriş_butonuna_tıklar()  {
		

		Actions action = new Actions(driver);
		WebElement element = driver.findElement(By.id("myAccount"));
		
		action.moveToElement(element).build().perform();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
	    WebElement element2 = driver.findElement(By.id("login"));
        action.moveToElement(element2);
      	action.click().build().perform();
		
		
		
 

	  
	}

	@Then("^Emaili adresini girer$")
	public void emaili_adresini_girer() {
		
		driver.findElement(By.id("txtUserName")).sendKeys("username");
		

	
	}

	@Then("^Şifresini girer$")
	public void şifresini_girer()  {

		driver.findElement(By.id("txtPassword")).sendKeys("password");
	}

	@Then("^Giriş yapa tıklar$")
	public void giriş_yapa_tıklar() {
	}

	@Then("^Siteye girdiği görülür\\.$")
	public void siteye_girdiği_görülür(){
	}
	
	
	
	@Then("^Kullanıcı arama işlemi yapar\\.$")
	public void kullanıcı_arama_işlemi_yapar(){
	}
	
	@Then("^Kullanıcı arama sonucunda gelen ürün listesinden ürün seçer ve ürün detay sayfasına gider\\.$")
	public void urun_detay_sayfasina_gitme(){
	}
	
	@Then("^Kullanıcı seçilen ürün için ürün detayda “Yorumlar” tabına gider\\.$")
	public void yoruma_gitme(){
	}
	
	@Then("^Kullanıcı gelen yorumlar içerisinde ilk yorumun “Evet” butonuna basar\\.$")
	public void evet_butonuna_tiklama(){
	}
	
	@Then("^Kullanıcı “Teşekkür Ederiz” yazısını görür\\.$")
	public void tesekkur_ederiz_kontrol(){
	}
	
	@Then("^Kullanıcı eğer yorumlar tab’ında hiç yorum gelmiyorsa herhangi bir işlem yapmaz\\.$")
	public void yorum_kontrol(){
	}
	
}
