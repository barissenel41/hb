package test;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
//import cucumber.api.junit.Cucumber;
import io.cucumber.testng.AbstractTestNGCucumberTests;


//import org.junit.runner.RunWith;


//@RunWith(Cucumber.class)
@CucumberOptions (
        features = {"/Users/cengiz.senel/git/BDDFramework/src/main/java/Features/login.feature"}
        ,glue = {"stepDefinition"},
        format= {"pretty","html:test-outout"},
        		tags = "@tag1"
                ,plugin = {
                		"html:target/cucumber-reports/report.html"        		
                		,"json:target/cucumber-reports/report.json"
                		,"usage:target/cucumber_usage.json"
                		}
		)


public class TestRunner {
	private TestNGCucumberRunner testNGCucumberRunner;
    
    @BeforeClass()
    public void setUpClass() throws Exception {
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
    }
     
    @Test(dataProvider="features")
    public void my_test(CucumberFeatureWrapper cucumberFeature)        {
      testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
  }
   
    @DataProvider
    public Object[][] features()
    {
        return testNGCucumberRunner.provideFeatures();      
    }
     

    public void tearDown()
    {
        testNGCucumberRunner.finish();
         
    }
}
	
	


