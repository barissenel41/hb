$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("/Users/cengiz.senel/git/BDDFramework/src/main/java/Features/login.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    },
    {
      "line": 2,
      "value": "#Keywords Summary :"
    },
    {
      "line": 3,
      "value": "#Feature: List of scenarios."
    },
    {
      "line": 4,
      "value": "#Scenario: Business rule through list of steps with arguments."
    },
    {
      "line": 5,
      "value": "#Given: Some precondition step"
    },
    {
      "line": 6,
      "value": "#When: Some key actions"
    },
    {
      "line": 7,
      "value": "#Then: To observe outcomes or validation"
    },
    {
      "line": 8,
      "value": "#And,But: To enumerate more Given,When,Then steps"
    },
    {
      "line": 9,
      "value": "#Scenario Outline: List of steps for data-driven as an Examples and \u003cplaceholder\u003e"
    },
    {
      "line": 10,
      "value": "#Examples: Container for s table"
    },
    {
      "line": 11,
      "value": "#Background: List of steps run before each of the scenarios"
    },
    {
      "line": 12,
      "value": "#\"\"\" (Doc Strings)"
    },
    {
      "line": 13,
      "value": "#| (Data Tables)"
    },
    {
      "line": 14,
      "value": "#@ (Tags/Labels):To group Scenarios"
    },
    {
      "line": 15,
      "value": "#\u003c\u003e (placeholder)"
    },
    {
      "line": 16,
      "value": "#\"\""
    },
    {
      "line": 17,
      "value": "## (Comments)"
    },
    {
      "line": 18,
      "value": "#Sample Feature Definition Template"
    }
  ],
  "line": 20,
  "name": "Siteye Giris",
  "description": "Siteye login olma",
  "id": "siteye-giris",
  "keyword": "Feature",
  "tags": [
    {
      "line": 19,
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "line": 24,
  "name": "Login olma",
  "description": "",
  "id": "siteye-giris;login-olma",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 23,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 25,
  "name": "Login olmak icin kullanıcı siteye girer",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "Giriş butonuna tıklar",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "Emaili adresini girer",
  "keyword": "Then "
});
formatter.step({
  "line": 28,
  "name": "Şifresini girer",
  "keyword": "Then "
});
formatter.step({
  "line": 29,
  "name": "Giriş yapa tıklar",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "Siteye girdiği görülür.",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "Kullanıcı arama işlemi yapar.",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "Kullanıcı arama sonucunda gelen ürün listesinden ürün seçer ve ürün detay sayfasına gider.",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "Kullanıcı seçilen ürün için ürün detayda “Yorumlar” tabına gider.",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "Kullanıcı gelen yorumlar içerisinde ilk yorumun “Evet” butonuna basar.",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "Kullanıcı “Teşekkür Ederiz” yazısını görür.",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "Kullanıcı eğer yorumlar tab’ında hiç yorum gelmiyorsa herhangi bir işlem yapmaz.",
  "keyword": "And "
});
formatter.match({
  "location": "LoginStepDefiniton.siteye_girme()"
});
formatter.result({
  "duration": 15641504483,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefiniton.giriş_butonuna_tıklar()"
});
formatter.result({
  "duration": 13054027077,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefiniton.emaili_adresini_girer()"
});
formatter.result({
  "duration": 7544763949,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefiniton.şifresini_girer()"
});
formatter.result({
  "duration": 452104781,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefiniton.giriş_yapa_tıklar()"
});
formatter.result({
  "duration": 30363,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefiniton.siteye_girdiği_görülür()"
});
formatter.result({
  "duration": 26065,
  "status": "passed"
});
formatter.match({
  "location": "LoginStepDefiniton.kullanıcı_arama_işlemi_yapar()"
});
formatter.result({
  "duration": 25448,
  "status": "passed"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
